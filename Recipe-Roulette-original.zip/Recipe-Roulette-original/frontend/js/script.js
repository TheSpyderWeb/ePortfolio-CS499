// ------------------- DOM ELEMENTS -------------------
const mealsEl = document.getElementById("meals");
const favoriteContainer = document.getElementById("fav-meals");
const mealPopup = document.getElementById("meal-popup");
const mealInfoEl = document.getElementById("meal-info");
const popupCloseBtn = document.getElementById("close-popup");

const searchTerm = document.getElementById("search-term");
const searchBtn = document.getElementById("search");

// ------------------- MEALDB API -------------------

getRandomMeal();
fetchFavMeals();

async function getRandomMeal() {
  const resp = await fetch("https://www.themealdb.com/api/json/v1/1/random.php");
  const respData = await resp.json();
  const randomMeal = respData.meals[0];
  addMeal(randomMeal, true);
}

async function getMealById(id) {
  const resp = await fetch("https://www.themealdb.com/api/json/v1/1/lookup.php?i=" + id);
  const respData = await resp.json();
  return respData.meals[0];
}

async function getMealsBySearch(term) {
  const resp = await fetch("https://www.themealdb.com/api/json/v1/1/search.php?s=" + term);
  const respData = await resp.json();
  return respData.meals;
}

// ------------------- ADD MEAL -------------------

function addMeal(mealData, random = false) {
  const meal = document.createElement("div");
  meal.classList.add("meal");

  meal.innerHTML = `
    <div class="meal-header">
      ${random ? `<span class="random"></span>` : ""}
      <img src="${mealData.strMealThumb}" alt="${mealData.strMeal}" />
    </div>
    <div class="meal-body">
      <h4>${mealData.strMeal}</h4>
      <button class="fav-btn"> Add <i class="fas fa-heart"></i></button>
    </div>
  `;

  const btn = meal.querySelector(".meal-body .fav-btn");
  btn.addEventListener("click", (e) => {
    e.stopPropagation(); // Prevent opening popup when clicking heart
    if (btn.classList.contains("active")) {
      removeMealLS(mealData.idMeal);
      btn.classList.remove("active");
    } else {
      addMealLS(mealData.idMeal);
      btn.classList.add("active");
    }
    fetchFavMeals();
  });

  meal.addEventListener("click", () => showMealInfo(mealData));

  mealsEl.appendChild(meal);
}

// ------------------- LOCAL STORAGE -------------------

function addMealLS(mealId) {
  const mealIds = getMealsLS();
  localStorage.setItem("mealIds", JSON.stringify([...mealIds, mealId]));
}

function removeMealLS(mealId) {
  const mealIds = getMealsLS();
  localStorage.setItem("mealIds", JSON.stringify(mealIds.filter(id => id !== mealId)));
}

function getMealsLS() {
  const mealIds = JSON.parse(localStorage.getItem("mealIds"));
  return mealIds === null ? [] : mealIds;
}

// ------------------- FAVORITES -------------------

async function fetchFavMeals() {
  favoriteContainer.innerHTML = "";
  const mealIds = getMealsLS();

  for (let i = 0; i < mealIds.length; i++) {
    const mealId = mealIds[i];
    const meal = await getMealById(mealId);
    addMealFav(meal);
  }
}

function addMealFav(mealData) {
  const favMeal = document.createElement("li");

  favMeal.innerHTML = `
    <img src="${mealData.strMealThumb}" alt="${mealData.strMeal}" />
    <span>${mealData.strMeal}</span>
    <button class="clear">Remove</button>
  `;

  const btn = favMeal.querySelector(".clear");
  btn.addEventListener("click", () => {
    removeMealLS(mealData.idMeal);
    fetchFavMeals();
  });

  favMeal.addEventListener("click", () => showMealInfo(mealData));

  favoriteContainer.appendChild(favMeal);
}

// ------------------- POPUP -------------------

function showMealInfo(mealData) {
  mealInfoEl.innerHTML = "";

  const mealEl = document.createElement("div");
  const ingredients = [];

  for (let i = 1; i <= 20; i++) {
    if (mealData["strIngredient" + i]) {
      ingredients.push(`${mealData["strIngredient" + i]} - ${mealData["strMeasure" + i]}`);
    } else break;
  }

  mealEl.innerHTML = `
    <h1>${mealData.strMeal}</h1>
    <img src="${mealData.strMealThumb}" alt="${mealData.strMeal}" />
    <p>${mealData.strInstructions}</p>
    <h3>Ingredients:</h3>
    <ul>${ingredients.map(ing => `<li>${ing}</li>`).join("")}</ul>
  `;

  mealInfoEl.appendChild(mealEl);
  mealPopup.classList.remove("hidden");
  mealPopup.classList.add("show");

  // Close button inside popup
  document.getElementById("close-meal-btn").addEventListener("click", () => {
    mealPopup.classList.add("hidden");
  });
}

// ------------------- SEARCH -------------------

searchBtn.addEventListener("click", async () => {
  mealsEl.innerHTML = "";
  const meals = await getMealsBySearch(searchTerm.value);
  if (meals) meals.forEach(meal => addMeal(meal));
});

// Close popup by clicking outside content
popupCloseBtn.addEventListener("click", () => mealPopup.classList.add("hidden"));
